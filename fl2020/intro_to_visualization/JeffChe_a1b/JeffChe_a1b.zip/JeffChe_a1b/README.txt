Resources used besides the textbook and assignment description:
    1. https://stackoverflow.com/questions/10090084/javascript-to-change-colour-of-an-svg-shape
    2. https://stackoverflow.com/questions/43367642/javascript-get-child-of-child
    3. https://stackoverflow.com/questions/3846015/flip-svg-coordinate-system
    4. https://www.w3schools.com/jsref/jsref_sort.asp
    5. https://bl.ocks.org/d3noob/a22c42db65eb00d4e369
    6. https://stackoverflow.com/questions/42722485/d3-how-to-use-exit-remove-for-multi-series-line-chart

Did Extra Credit 1: Hovering over a point in the scatterplot shows a tooltip with the x and y data values.