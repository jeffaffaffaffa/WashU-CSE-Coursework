// setting up browserify

const MonkeyLearn = require('monkeylearn');
const Sentiment = require('sentiment');

global.window.MonkeyLearn = MonkeyLearn;
global.window.Sentiment = Sentiment;